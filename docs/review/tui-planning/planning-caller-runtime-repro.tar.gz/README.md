# Planning caller and stored-revision runtime reproduction

This archive contains all executable local imports for seven focused planning caller suites: 44 runtime source files, package/config/preload support and two golden frames. Three extra runtime barrel/store files are included for source-boundary inspection. The 52 source/config/resource paths have current and immutable upstream SHA-256 hashes in source-manifest.json. This is a complete reproduction of the listed runtime tests, not a full product type graph or binary build.

The exact isolated-copy run passes 50 tests / 171 assertions. It includes the real command registry, real ConfigModal host, and real KnowledgeStore/ProjectPlanningService SQLite writes. Five new end-to-end store cases cover delayed approval and answer writes after a same-millisecond replacement, a changed source after awaited evaluation with unchanged synthetic question text, repeated Enter events, and numeric selected IDs versus manual indexes. Held actions leave persisted bytes and reopened sources/work plans unchanged. Other cases cover deferred command promises, errors, close/reopen admission, missing legacy revisions, custom entry and held semantic readings.

## Reconstruct

1. Start from public monorepo main cef1a3d529797d63ddb8e95f48904ec76c638dca. Apply engine-composition.patch, the exact nine-file THE95 delta at c70f79ecccca21a8a08400626c4f8f748fa2bd29 (tree 2969dc3571e741d1061f88cf620ff1f1dfe1b85f). This main already contains PR51's planning reader and cancellation correction. The engine source in tested product composition 142fc8e620b26177200b256856f6d639996268f5 is byte-identical to this engine commit.
2. Materialize immutable upstream TUI ec057c33979839be84a1d8d2399f9c69f0c2a5aa into products/tui, then overlay overlay/products/tui. Apply workspace-lock.patch for the matching declared workspace dependencies. It contains only the existing 22-line TUI workspace/alias/fuse addition to main's lock.
3. Use matching scripts-disabled workspace dependencies. The copied-source verification used the TUI's existing owned dependency ancestry, resolving public Jev engine/judgment aliases to the same actual checkout. It created no dependency symlink or second installation. No node_modules, credentials, user state or external provider calls are included.
4. Run from the monorepo root:

```sh
bun packages/engine/scripts/test.ts --cwd ../../products/tui src/test/views/modals/planning-modal.test.ts src/test/views/modals/pr51-independent-races.test.ts src/test/views/modals/planning-modal-admission.test.ts src/test/views/modals/planning-modal-store.test.ts src/test/input/planning-action-target.test.ts src/test/input/planning-runtime-command.test.ts src/test/renderer/planning-modal-golden.test.ts
```

The guard keeps home/temp state isolated and disallows external network access. The attached reconstructed-runtime.log is from running the copied archive source under the original product's owned dependency ancestry. Every source hash was checked again after execution.

## Review history and acceptance

The original nine-file packet was incomplete for four real-command cases. This archive supersedes it for reproduction and includes adapted runtime-services plus its full executable closure. The two exact original portable probes were run unchanged before repair and their bytes/failing log remain under review-evidence. Maintained race fixtures now explicitly include the new stored-revision contract; their scheduling and expected one-admission/no-stale-approval behavior remain. A separate regression requires legacy missing revisions to hold view mutations, so fixture metadata is not used as a production fallback.

The TUI copies the selected revision, admits one pending action synchronously, preserves the binding through evaluation and awaited command execution, and dispatches it to the actual conditional store action. Manual commands explicitly select current mode. This proves the listed caller/store acceptance boundaries locally. Engine publication/review/CI, full TUI source/test types, packaging and compiled startup remain separate. The legacy trusted-admin upsert route still permits explicit executionApproved input; a source generation is a concurrency precondition, not an authorization grant.
