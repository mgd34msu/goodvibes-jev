import type { Line } from '@goodvibes-jev/engine/sdk/platform/types';
import { createEmptyLine, createStyledCell } from '@goodvibes-jev/engine/sdk/platform/types';
import { getDisplayWidth, wrapText } from '../utils/terminal-width.ts';
import { getSurfaceContentRows, getTrackedVisibleWindow, getVisibleWindow, type VisibleWindow } from '../renderer/surface-layout.ts';
import { GLYPHS } from '../renderer/ui-primitives.ts';
import { type StatusState, STATE_GLYPHS } from '../renderer/status-glyphs.ts';
import { buildViewLine, buildStyledViewLine, DEFAULT_VIEW_PALETTE } from './polish-core.ts';
import type { ViewPalette, StyledViewSegment } from './polish-core.ts';

// The view formatting toolkit is split across three modules to stay under the
// architecture line-count cap; every symbol remains importable from './polish.ts':
//   - ./polish-core.ts    palette + base line primitives (leaf)
//   - ./polish-tables.ts  table / tree / badge / aligned-row primitives
// This module keeps the higher-level builders + workspace layout.
export * from './polish-core.ts';
export {
  buildAlignedRow,
  buildStatusBadge,
  buildTreeRow,
  buildTable,
  type ColumnAlign,
  type ColumnSpec,
  type AlignedCell,
  type StatusBadgeKind,
  type TreeItemSpec,
  type TableColumn,
  type TableCell,
  type TableRow,
} from './polish-tables.ts';

export function buildGuidanceLine(
  width: number,
  command: string,
  summary: string,
  palette: ViewPalette,
): Line {
  return buildViewLine(width, [
    [` ${GLYPHS.status.info} `, palette.info],
    [command, palette.info],
    ['  - ', palette.dim],
    [summary, palette.dim],
  ]);
}

export function buildViewTitle(
  width: number,
  title: string,
  palette: ViewPalette,
): Line {
  // Two columns between the fill edge and the title (the Measurements padding rule).
  const titleText = fitDisplayText(`  ${title}`, width);
  return buildStyledViewLine(width, [
    { text: titleText, fg: palette.header ?? palette.accent ?? palette.value, bg: palette.headerBg, bold: true },
  ], { fillBg: palette.headerBg });
}

export function buildBodyText(
  width: number,
  text: string,
  palette: ViewPalette,
  fg: string = palette.value,
): Line[] {
  const wrapped = wrapText(text, Math.max(10, width - 2));
  return wrapped.map((line) => buildStyledViewLine(width, [{ text: ` ${line}`, fg, bg: palette.surfaceBg }], { fillBg: palette.surfaceBg }));
}

export function buildSectionHeader(
  width: number,
  title: string,
  palette: ViewPalette,
): Line {
  const prefix = `${GLYPHS.status.dualPane} ${title}`;
  const divider = GLYPHS.frame.horizontal.repeat(Math.max(0, width - getDisplayWidth(prefix) - 2));
  return buildStyledViewLine(width, [
    { text: ' ', fg: palette.label, bg: palette.sectionBg },
    { text: prefix, fg: palette.label, bg: palette.sectionBg, bold: true },
    { text: ' ', fg: palette.dim, bg: palette.sectionBg },
    { text: divider, fg: palette.dim, bg: palette.sectionBg },
  ], { fillBg: palette.sectionBg });
}

export function buildKeyValueLine(
  width: number,
  entries: ReadonlyArray<{ label: string; value: string; valueColor?: string }>,
  palette: ViewPalette,
): Line {
  const segments: Array<[string, string, string?]> = [];
  for (const entry of entries) {
    segments.push([' ', palette.label]);
    segments.push([`${entry.label} `, palette.label]);
    segments.push([entry.value, entry.valueColor ?? palette.value]);
    segments.push(['  ', palette.dim]);
  }
  return buildStyledViewLine(width, segments.map(([text, fg, bg]) => ({ text, fg, bg: bg ?? palette.summaryBg })), { fillBg: palette.summaryBg });
}

export function buildShortcutLine(
  width: number,
  keys: string,
  summary: string,
  palette: ViewPalette,
): Line {
  return buildViewLine(width, [
    ['  ', palette.label],
    [keys, palette.info],
    ['  ', palette.dim],
    [summary, palette.dim],
  ]);
}

export function buildViewListRow(
  width: number,
  segments: ReadonlyArray<StyledViewSegment>,
  palette: ViewPalette,
  options: {
    readonly selected?: boolean;
    readonly selectedBg?: string;
    readonly marker?: string;
    readonly markerColor?: string;
    readonly fillBg?: string;
  } = {},
): Line {
  const selected = options.selected ?? false;
  const selectedBg = options.selectedBg ?? palette.selectBg;
  const fillBg = selected ? selectedBg : options.fillBg;
  const marker = selected ? `${options.marker ?? GLYPHS.navigation.selected} ` : '  ';
  const markerFg = selected ? (options.markerColor ?? palette.info) : palette.dim;
  return buildStyledViewLine(width, [
    { text: marker, fg: markerFg, bg: fillBg, bold: selected },
    ...segments.map((segment) => ({
      ...segment,
      bg: segment.bg ?? fillBg,
    })),
  ], { fillBg });
}

export function buildSearchInputLine(
  width: number,
  label: string,
  value: string,
  palette: ViewPalette,
  options: { active?: boolean; bg?: string; emptyLabel?: string; valueColor?: string } = {},
): Line {
  const active = options.active ?? false;
  const normalizedValue = active && value.endsWith('_')
    ? `${value.slice(0, -1)}${GLYPHS.surface.cursor}`
    : value;
  const hasValue = normalizedValue.trim().length > 0;
  const content = hasValue ? normalizedValue : (options.emptyLabel ?? '(none)');
  const bg = options.bg ?? (active ? palette.inputBg : palette.sectionBg);
  const fg = active
    ? options.valueColor ?? palette.info
    : hasValue
      ? options.valueColor ?? palette.value
      : palette.dim;
  // Two columns of padding on both sides of the fill; a long draft keeps its
  // end (where the cursor is) in view.
  const room = Math.max(1, width - 4 - getDisplayWidth(label));
  let shown = content;
  while (shown.length > 0 && getDisplayWidth(shown) > room) shown = shown.slice(1);
  return buildStyledViewLine(width, [
    { text: '  ', fg: palette.label, bg },
    { text: `${label}`, fg: palette.label, bg },
    { text: shown, fg, bg, bold: active },
  ], { fillBg: bg });
}

/**
 * Build a status pill segment (glyph + label) for use in buildViewLine.
 *
 * Returns StyledViewSegment[], spread directly into a buildViewLine segments
 * array:
 *   buildViewLine(width, [['  count ', C.label], ...buildStatusPill('bad', '3')])
 *
 * Convention: raw hex colors may only live inside a palette constant declared at
 * the top of a view file; buildStatusPill derives its color from the palette.
 */
export function buildStatusPill(
  state: StatusState,
  label: string,
  opts?: { glyph?: string; bg?: string; count?: number },
): StyledViewSegment[] {
  const glyph = opts?.glyph ?? STATE_GLYPHS[state];
  const color = state === 'good' ? DEFAULT_VIEW_PALETTE.good
    : state === 'warn' ? DEFAULT_VIEW_PALETTE.warn
    : state === 'bad'  ? DEFAULT_VIEW_PALETTE.bad
    : DEFAULT_VIEW_PALETTE.info;
  const bg = opts?.bg;
  const text = opts?.count !== undefined ? `${glyph} ${label} (${opts.count})` : `${glyph} ${label}`;
  return [{ text, fg: color, bg }];
}

export function buildStatPill(
  label: string,
  value: string,
  labelColor: string,
  valueColor: string,
  bg = '',
): Array<[string, string, string?]> {
  return [
    [' ', labelColor, bg],
    [label, labelColor, bg],
    [' ', labelColor, bg],
    [value, valueColor, bg],
    ['  ', labelColor, bg],
  ];
}

export function buildMeterLine(
  width: number,
  filled: number,
  total: number,
  colors: { filled: string; empty: string; label?: string },
  options: { prefix?: string; suffix?: string; filledChar?: string; emptyChar?: string } = {},
): Line {
  const prefix = options.prefix ?? ' ';
  const suffix = options.suffix ?? ' ';
  const emptyChar = options.emptyChar ?? GLYPHS.meter.empty;
  const normalizedFilledChar = options.filledChar ?? GLYPHS.meter.filled;
  const barWidth = Math.max(1, total);
  const clampedFilled = Math.max(0, Math.min(barWidth, filled));
  const segments: StyledViewSegment[] = [{ text: prefix, fg: colors.label ?? colors.filled }];
  if (clampedFilled > 0) {
    segments.push({ text: normalizedFilledChar.repeat(clampedFilled), fg: colors.filled });
  }
  if (clampedFilled < barWidth) {
    segments.push({ text: emptyChar.repeat(barWidth - clampedFilled), fg: colors.empty });
  }
  segments.push({ text: suffix, fg: colors.label ?? colors.filled });
  return buildStyledViewLine(width, segments);
}

export function buildEmptyState(
  width: number,
  title: string,
  body: string,
  actions: ReadonlyArray<{ command: string; summary: string }>,
  palette: ViewPalette,
): Line[] {
  const lines: Line[] = [];
  lines.push(buildViewLine(width, [[` ${title}`, palette.empty]]));
  lines.push(...buildBodyText(width, body, palette, palette.dim));
  if (actions.length > 0) {
    lines.push(buildViewLine(width, [[' Suggested next steps', palette.label]]));
    for (const action of actions) {
      lines.push(buildGuidanceLine(width, action.command, action.summary, palette));
    }
  }
  return lines;
}

export function buildSummaryBlock(
  width: number,
  title: string,
  rows: readonly Line[],
  palette: ViewPalette,
): Line[] {
  const lines: Line[] = [
    buildStyledViewLine(width, [
      { text: ` ${GLYPHS.status.active} ${title}`, fg: palette.header ?? palette.value, bg: palette.summaryBg, bold: true },
    ], { fillBg: palette.summaryBg }),
  ];
  for (const row of rows) lines.push(row);
  return lines;
}

export function buildDetailBlock(
  width: number,
  title: string,
  rows: readonly Line[],
  palette: ViewPalette,
): Line[] {
  return [
    buildStyledViewLine(width, [
      { text: ` ${GLYPHS.status.review} ${title}`, fg: palette.header ?? palette.value, bg: palette.sectionBg, bold: true },
    ], { fillBg: palette.sectionBg }),
    ...rows.map((row) => row.map((cell) => (
      cell.bg
        ? cell
        : createStyledCell(cell.char, {
            fg: cell.fg,
            bg: palette.surfaceBg,
            bold: cell.bold,
            dim: cell.dim,
            underline: cell.underline,
          })
    ))),
  ];
}

function fitDisplayText(text: string, width: number): string {
  let col = 0;
  let out = '';
  for (const ch of text) {
    const w = getDisplayWidth(ch);
    if (w <= 0 || col + w > width) break;
    out += ch;
    col += w;
  }
  return out;
}

export interface ViewWorkspaceSection {
  readonly title?: string;
  readonly lines: readonly Line[];
}

export interface PrimaryScrollableViewSectionConfig {
  readonly title?: string;
  readonly fixedLines?: readonly Line[];
  readonly scrollableLines: readonly Line[];
  readonly selectedIndex: number;
  readonly scrollOffset: number;
  readonly guardRows?: number;
  readonly minRows?: number;
  readonly appendWindowSummary?: {
    readonly dimColor?: string;
    readonly formatter?: (window: VisibleWindow) => Line;
  };
}

export interface ScrollableViewSectionConfig {
  readonly title?: string;
  readonly fixedLines?: readonly Line[];
  readonly scrollableLines: readonly Line[];
  readonly scrollOffset: number;
  readonly selectedIndex?: number;
  readonly guardRows?: number;
  readonly minRows?: number;
  readonly appendWindowSummary?: {
    readonly dimColor?: string;
    readonly formatter?: (window: VisibleWindow) => Line;
  };
}

export interface StackedScrollableViewSectionConfig extends ScrollableViewSectionConfig {
  readonly weight?: number;
}

export interface ViewWorkspaceConfig {
  readonly title: string;
  readonly intro?: string;
  readonly sections: readonly ViewWorkspaceSection[];
  readonly footerLines?: readonly Line[];
  readonly palette: ViewPalette;
}

function getViewWorkspaceIntroRows(
  width: number,
  intro: string | undefined,
  palette: ViewPalette,
): number {
  return intro ? buildBodyText(width, intro, palette, palette.dim).length : 0;
}

export function getViewWorkspaceContentBudget(
  width: number,
  height: number,
  config: Pick<ViewWorkspaceConfig, 'intro' | 'footerLines' | 'palette'>,
): number {
  const footerLines = [...(config.footerLines ?? [])];
  const chromeRows = 1 + getViewWorkspaceIntroRows(width, config.intro, config.palette) + footerLines.length;
  return Math.max(
    1,
    getSurfaceContentRows({
      viewportHeight: height,
      chromeRows,
      minContentRows: 4,
      maxContentRows: Math.max(4, height - chromeRows),
      minTotalRows: 8,
      maxTotalRows: Math.max(8, height),
      targetRatio: 1,
    }),
  );
}

export function getViewWorkspaceSectionRows(section: ViewWorkspaceSection): number {
  return (section.title ? 1 : 0) + section.lines.length;
}

export function getViewScrollableSectionBudget(
  width: number,
  height: number,
  options: {
    readonly intro?: string;
    readonly footerLines?: readonly Line[];
    readonly palette: ViewPalette;
    readonly beforeSections?: readonly ViewWorkspaceSection[];
    readonly currentSectionTitle?: string;
    readonly currentSectionFixedRows?: number;
    readonly afterSections?: readonly ViewWorkspaceSection[];
    readonly minRows?: number;
  },
): number {
  const contentBudget = getViewWorkspaceContentBudget(width, height, options);
  const beforeRows = (options.beforeSections ?? []).reduce((sum, section) => sum + getViewWorkspaceSectionRows(section), 0);
  const afterRows = (options.afterSections ?? []).reduce((sum, section) => sum + getViewWorkspaceSectionRows(section), 0);
  const currentHeaderRows = options.currentSectionTitle ? 1 : 0;
  const currentFixedRows = Math.max(0, options.currentSectionFixedRows ?? 0);
  return Math.max(options.minRows ?? 1, contentBudget - beforeRows - currentHeaderRows - currentFixedRows - afterRows);
}

export function resolvePrimaryScrollableSection(
  width: number,
  height: number,
  options: {
    readonly intro?: string;
    readonly footerLines?: readonly Line[];
    readonly palette: ViewPalette;
    readonly beforeSections?: readonly ViewWorkspaceSection[];
    readonly section: PrimaryScrollableViewSectionConfig;
    readonly afterSections?: readonly ViewWorkspaceSection[];
  },
): {
  readonly section: ViewWorkspaceSection;
  readonly scrollOffset: number;
  readonly window: VisibleWindow;
} {
  return resolveScrollableViewSection(width, height, {
    intro: options.intro,
    footerLines: options.footerLines,
    palette: options.palette,
    beforeSections: options.beforeSections,
    section: options.section,
    afterSections: options.afterSections,
  });
}

export function resolveScrollableViewSection(
  width: number,
  height: number,
  options: {
    readonly intro?: string;
    readonly footerLines?: readonly Line[];
    readonly palette: ViewPalette;
    readonly beforeSections?: readonly ViewWorkspaceSection[];
    readonly section: ScrollableViewSectionConfig;
    readonly afterSections?: readonly ViewWorkspaceSection[];
  },
): {
  readonly section: ViewWorkspaceSection;
  readonly scrollOffset: number;
  readonly window: VisibleWindow;
} {
  const fixedLines = [...(options.section.fixedLines ?? [])];
  const budget = getViewScrollableSectionBudget(width, height, {
    intro: options.intro,
    footerLines: options.footerLines,
    palette: options.palette,
    beforeSections: options.beforeSections,
    currentSectionTitle: options.section.title,
    currentSectionFixedRows: fixedLines.length,
    afterSections: options.afterSections,
    minRows: options.section.minRows ?? 1,
  });
  // When a window-summary row will render (list longer than the budget can
  // show), it occupies one of the section's rows. Reserve that row up front so
  // the summary is accounted INSIDE the budget; otherwise the appended summary
  // pushes total output one line past the view's exact-height contract and the
  // tail line (typically the footer's keyboard-hints row) is silently dropped.
  const summaryReserved = options.section.appendWindowSummary
    && options.section.scrollableLines.length > budget
    ? 1
    : 0;
  const windowBudget = Math.max(0, budget - summaryReserved);
  const window = options.section.selectedIndex === undefined
    ? getVisibleWindow(
        options.section.scrollableLines.length,
        options.section.scrollOffset,
        windowBudget,
      )
    : getTrackedVisibleWindow(
        options.section.scrollableLines.length,
        options.section.selectedIndex,
        windowBudget,
        options.section.scrollOffset,
        options.section.guardRows ?? 1,
      );
  const lines = [
    ...fixedLines,
    ...options.section.scrollableLines.slice(window.start, window.end),
  ];
  if (options.section.appendWindowSummary && options.section.scrollableLines.length > window.count) {
    const summary = options.section.appendWindowSummary.formatter
      ? options.section.appendWindowSummary.formatter(window)
      : buildViewLine(width, [[`  showing ${window.start + 1}-${window.end} of ${window.total}`, options.section.appendWindowSummary.dimColor ?? options.palette.dim]]);
    lines.push(summary);
  }
  return {
    section: {
      title: options.section.title,
      lines,
    },
    scrollOffset: window.start,
    window,
  };
}

export function resolveStackedScrollableSections(
  width: number,
  height: number,
  options: {
    readonly intro?: string;
    readonly footerLines?: readonly Line[];
    readonly palette: ViewPalette;
    readonly beforeSections?: readonly ViewWorkspaceSection[];
    readonly sections: readonly StackedScrollableViewSectionConfig[];
    readonly afterSections?: readonly ViewWorkspaceSection[];
  },
): ReadonlyArray<{
  readonly section: ViewWorkspaceSection;
  readonly scrollOffset: number;
  readonly window: VisibleWindow;
}> {
  if (options.sections.length === 0) return [];
  const contentBudget = getViewWorkspaceContentBudget(width, height, options);
  const beforeRows = (options.beforeSections ?? []).reduce((sum, section) => sum + getViewWorkspaceSectionRows(section), 0);
  const afterRows = (options.afterSections ?? []).reduce((sum, section) => sum + getViewWorkspaceSectionRows(section), 0);
  const fixedChrome = options.sections.reduce((sum, section) => (
    sum
    + (section.title ? 1 : 0)
    + (section.fixedLines?.length ?? 0)
  ), 0);
  const allocatable = Math.max(1, contentBudget - beforeRows - afterRows - fixedChrome);
  const mins = options.sections.map((section) => Math.max(1, section.minRows ?? 1));
  const weights = options.sections.map((section) => Math.max(1, section.weight ?? 1));
  const totalMin = mins.reduce((sum, value) => sum + value, 0);
  const budgets = [...mins];
  let remaining = Math.max(0, allocatable - totalMin);
  const totalWeight = weights.reduce((sum, value) => sum + value, 0);
  for (let i = 0; i < budgets.length; i++) {
    if (remaining <= 0) break;
    const share = i === budgets.length - 1
      ? remaining
      : Math.floor((remaining * weights[i]!) / totalWeight);
    budgets[i]! += share;
    remaining -= share;
  }
  let cursor = 0;
  while (remaining > 0 && budgets.length > 0) {
    budgets[cursor % budgets.length]! += 1;
    remaining--;
    cursor++;
  }

  return options.sections.map((section, index) => {
    const fixedLines = [...(section.fixedLines ?? [])];
    // Same reservation as resolveScrollableViewSection: a window-summary row
    // occupies one of this section's allocated rows, so shrink the visible
    // window rather than overflowing the stack's exact-height budget.
    const budget = budgets[index]!;
    const summaryReserved = section.appendWindowSummary
      && section.scrollableLines.length > budget
      ? 1
      : 0;
    const windowBudget = Math.max(0, budget - summaryReserved);
    const window = section.selectedIndex === undefined
      ? getVisibleWindow(section.scrollableLines.length, section.scrollOffset, windowBudget)
      : getTrackedVisibleWindow(
          section.scrollableLines.length,
          section.selectedIndex,
          windowBudget,
          section.scrollOffset,
          section.guardRows ?? 1,
        );
    const lines = [
      ...fixedLines,
      ...section.scrollableLines.slice(window.start, window.end),
    ];
    if (section.appendWindowSummary && section.scrollableLines.length > window.count) {
      const summary = section.appendWindowSummary.formatter
        ? section.appendWindowSummary.formatter(window)
        : buildViewLine(width, [[`  showing ${window.start + 1}-${window.end} of ${window.total}`, section.appendWindowSummary.dimColor ?? options.palette.dim]]);
      lines.push(summary);
    }
    return {
      section: {
        title: section.title,
        lines,
      },
      scrollOffset: window.start,
      window,
    };
  });
}

/**
 * Standardized footer keyboard-hint row so every view's hints look identical.
 * Each hint renders as `keys` (info color) + `label` (dim).
 */
export function buildKeyboardHints(
  width: number,
  hints: ReadonlyArray<{ keys: string; label: string }>,
  palette: ViewPalette,
): Line {
  const segments: Array<[string, string, string?]> = [];
  hints.forEach((hint, i) => {
    if (i > 0) segments.push(['   ', palette.dim]);
    else segments.push([' ', palette.dim]);
    segments.push([hint.keys, palette.info]);
    segments.push([' ', palette.dim]);
    segments.push([hint.label, palette.dim]);
  });
  return buildViewLine(width, segments);
}

export function buildViewWorkspace(
  width: number,
  height: number,
  config: ViewWorkspaceConfig,
): Line[] {
  const lines: Line[] = [];
  lines.push(buildViewTitle(width, config.title, config.palette));
  if (config.intro) {
    lines.push(...buildBodyText(width, config.intro, config.palette, config.palette.dim));
  }
  const footerLines = [...(config.footerLines ?? [])];
  const contentBudget = getViewWorkspaceContentBudget(width, height, config);

  let consumed = 0;
  for (let sectionIndex = 0; sectionIndex < config.sections.length; sectionIndex++) {
    const section = config.sections[sectionIndex]!;
    if (consumed >= contentBudget) break;
    if (section.title) {
      if (consumed >= contentBudget) break;
      lines.push(buildSectionHeader(width, section.title, config.palette));
      consumed++;
    }
    for (const line of section.lines) {
      if (consumed >= contentBudget) break;
      lines.push(line);
      consumed++;
    }
  }

  const contentAndChromeTarget = Math.max(0, height - footerLines.length);
  while (lines.length < contentAndChromeTarget) lines.push(createEmptyLine(width));
  lines.push(...footerLines);
  while (lines.length < height) lines.push(createEmptyLine(width));
  return lines.slice(0, height);
}
